# 通过Kafka实现Oracle迁移同步(Xstream模式)数据到YaShanDB配置说明



> **⚠️ 重要法律与风险提示**
>
> 在按照本文档进行操作前，**请务必先阅读并理解文档末尾的【免责声明】章节**。该章节包含重要的法律声明、第三方软件许可要求（特别是Oracle XStream功能的授权信息）以及操作风险提示。继续阅读本文档即表示您已了解相关风险和责任。



此文档的目的是方便开发人员、测试人员、SA快速搭建通过oracle xstream 的方式同步数据到YaShanDB 的简单环境,，复杂环境可以在此基础上进一步拓展，下面分别从数据库服务器配置、Kafka配置、Kafka Connector配置、Source配置、Sink配置进行说明，也可以参考官方发布的配置文档：

1). Oracle官方XStream out配置说明：https://docs.oracle.com/en/database/oracle/oracle-database/19/xstrm/xstream-out.html

2). Confluent connector官方配置说明: https://docs.confluent.io/kafka-connectors/jdbc/current/sink-connector/sink_config_options.html

3). Debezium Connector for Oracle官方配置说明
https://debezium.io/documentation/reference/stable/connectors/oracle.html#oracle-xstreams-support
https://debezium.io/documentation/reference/stable/connectors/oracle.html#oracle-xstreams-setup

环境准备：

1). 服务器上已经安装 Oracle 19c 版本的数据库系统，具备数据库管理员权限或具有足够权限执行配置步骤的用户，比如sys用户。如果是其它版本的数据库，也可以参考本文档；

2). 服务器上已经安装YaShanDB23.4.1.102

3). CentOS7服务器上已经安装 kafka2.12-3.7.2 kraft单机版, JDK17

## 1. 源端Oracle数据库配置

### 1.1 启动数据库的归档模式archivelog
在oracle数据库安装服务器上使用sqlplus命令登录：
```
sqlplus / as sysdba
```
sqlplus登录之后执行如下命令：
```
select log_mode from v$database;   --查询当前日志模式
alter system set db_recovery_file_dest_size = 10G;
alter system set db_recovery_file_dest = '/opt/oracle/oradata/recovery_area' scope=spfile;   #注意：此目录必须存在
shutdown immediate;
startup mount;
alter database archivelog; --启动归档日志
alter database open;
alter system set enable_goldengate_replication= true; --启用 GoldenGate 复制功能
SELECT name, value, issys_modifiable FROM v$parameter WHERE name = 'enable_goldengate_replication';  --查询GoldenGate的值

ALTER DATABASE ADD SUPPLEMENTAL LOG DATA; --启用最小补充日志,可以根据需要配置最大补充
```
说明如下：

1).设置db_recovery_file_dest的目的是为了防止在一些特定情况下日志数据的丢失，比如在LCR生成速度大于LCR的消费速度时

2).若未开启归档，需挂载数据库执行，故需要先把数据库系统shutdown

### 1.2 创建XStream管理员用户
根据数据库安全原则、权限管理最佳实践，Oracle官方强烈建议采用XStream用户来执行相关的操作，而不是直接采用SYS用户来执行XStream相关的操作。

1. 配置XStream的表空间，采用sys用户登录(sqlplus / as sysdba),执行如下命令
```
SHOW CON_NAME;  --查询当前容器
-- 在CDB$ROOT根容器下执行下面一条指令
CREATE TABLESPACE xstream_tbs DATAFILE '/opt/oracle/oradata/dbs/xstream_tbs.dbf'   SIZE 25M REUSE AUTOEXTEND ON MAXSIZE UNLIMITED;

ALTER SESSION SET CONTAINER=ORCLPDB1;   --切换到ORCLPDB1容器下执行
--在ORCLPDB1容器下执行下面一条指令
CREATE TABLESPACE xstream_tbs DATAFILE '/opt/oracle/oradata/dbs/xstream_tbs_pdb.dbf'   SIZE 25M REUSE AUTOEXTEND ON MAXSIZE UNLIMITED;

ALTER SESSION SET CONTAINER=CDB$ROOT;   --回到CDB$ROOT根容器下
```
说明如下：

需要提前创建好目录和权限，否则上面命令会提示失败：

mkdir -p /opt/oracle/oradata/dbs/

chmod -R 777 /opt/oracle/oradata/dbs/

这里还需要特别注意，在Oracle 19c 的CDB模式下，需要分别在CDB\$ROOT、 ORCLPDB容器(其中ORCLPDB可能包含多个)会话中分别创建表空间，否则下面创建xstream管理用户会失败，另外，还需要注意，安装的数据库服务器上既有CDB也有PDB(即CDB$ROOT、 ORCLPDB1在一台服务器上)，表空间的路径不要相同

2. 创建XStream管理员用户，并且授权，执行如下命令
```
CREATE USER c##xstrmadmin IDENTIFIED BY "123456" DEFAULT TABLESPACE xstream_tbs  QUOTA UNLIMITED ON xstream_tbs CONTAINER=ALL;
GRANT CREATE SESSION, RESOURCE, SET CONTAINER TO c##xstrmadmin CONTAINER=ALL;
GRANT ALTER SYSTEM TO c##xstrmadmin;
GRANT SYSDBA TO c##xstrmadmin; --在其它所有PDB相关的容器上执行此命令
GRANT CREATE USER TO c##xstrmadmin CONTAINER=ALL;
GRANT ALTER USER TO c##xstrmadmin CONTAINER=ALL;
GRANT DROP USER TO c##xstrmadmin CONTAINER=ALL;
GRANT UNLIMITED TABLESPACE TO c##xstrmadmin CONTAINER=ALL;
GRANT SET CONTAINER TO c##xstrmadmin CONTAINER=ALL;  -- 确保有容器切换权限
-- 可选：授予查看数据字典权限
GRANT SELECT ANY DICTIONARY TO c##xstrmadmin CONTAINER=ALL;

--作为xstream 客户端用户访问out server时需要下面的权限
GRANT EXECUTE ON DBMS_XSTREAM_ADM TO c##xstrmadmin;
GRANT EXECUTE ON DBMS_XSTREAM_AUTH TO c##xstrmadmin;
GRANT DEQUEUE ANY QUEUE TO c##xstrmadmin CONTAINER=ALL;
GRANT DBA TO c##xstrmadmin CONTAINER=ALL;
GRANT SELECT ANY TABLE TO c##xstrmadmin;
ALTER USER c##xstrmadmin QUOTA UNLIMITED ON USERS;
```
说明如下:

1). 上面在创建XStream管理员用户的时候，CONTAINER=ALL表示该用户在所有容器（CDB和PDB）中有效


3. 设置XStream pool空间

采用XStream管理员用户(c##xstrmadmin)重新登录数据库，执行如下命令：
```
SHOW PARAMETER streams_pool_size;
ALTER SYSTEM SET STREAMS_POOL_SIZE = 512M SCOPE=SPFILE;
```
说明如下：

1).如果查询时streams_pool_size的容量值为0,请按照上述进行修改，否则会导致后面的CREATE_OUTBOUND过程无法执行完成(一直处于等待状态)，并且capture进程也无法启动，并且不报错。

2).上述配置需要重新启动数据库生效：
```
sqlplus / as sysdba

-- 立即关闭数据库
SHUTDOWN IMMEDIATE;

-- 启动数据库
STARTUP;
```



### 1.3 创建OUT BOUND,并启动capture进程
采用c##xstrmadmin登录数据库系统，之后即可创建OUTBOUND，并分配相关资源，具体参考如下操作步骤。

#### 1.3.1 创建OUTBOUND
```
DECLARE
    tables  DBMS_UTILITY.UNCL_ARRAY;
    schemas DBMS_UTILITY.UNCL_ARRAY;
BEGIN
    tables(1)  := 'HHL002.test001';
    schemas(1) := 'HHL001';
    DBMS_XSTREAM_ADM.CREATE_OUTBOUND(
            server_name     =>  'XOUT',
            table_names     =>  tables,
            schema_names    =>  schemas);
END;
```
说明如下：

1).此配置会捕获HHL001模式下的所有表变更，以及HHL002模式下的test001表变更。因此，请确保这些表存在并可访问
2).如果只想捕获schema HHL001下面的表变更数据，可以把上述配置项目的tables(1)配置为NULL ，即 tables(1)  := NULL;

#### 1.3.2 启动并授权外部通过用户连接访问

```
--启动XOUT
BEGIN
  DBMS_XSTREAM_ADM.START_OUTBOUND('XOUT');
  COMMIT;
END;


--授权给C##HHL01用户访问XOUT，否则无法访问XOUT
BEGIN
  DBMS_XSTREAM_ADM.ALTER_OUTBOUND(
    server_name  => 'XOUT',
    connect_user => 'c##xstrmadmin'
  );
END;
```
说明如下：

1). 在生产环境中，connect_user应使用权限更小的专用用户，而非c##xstrmadmin，而此用户的权限非常大，不符合最小化权限安全规则。

#### 1.3.3 相关OUTBOUND查询语句
创建OUTBOUND之后，数据库后台会启动相关进程、队列和相关配套资源，可以通过如下一些语句进行查询，这些语句可协助定位一些问题：
```
--查询servername对应的队列名，比如是Q$_XOUT_5，此队列就时LCR缓存队列
SELECT * FROM dba_xstream_outbound  -- 出站队列
--查询Q$_XOUT_5队列的详细信息，包括对应的队列表的名字,比如对应为QT$_XOUT_6
SELECT *FROM dba_queues WHERE name = 'Q$_XOUT_5';

--根据上面队列表的名字，查询队列表的详细信息
SELECT * FROM dba_queue_tables where queue_table='QT$_XOUT_6';

--模糊查找对象
SELECT * FROM all_objects WHERE object_name LIKE '%XOUT_6%'; 

--查询队列的使用情况，注意AQ$QT$_XOUT_6表名是通过上面的语句查询所得到的，名称由系统自动生成
SELECT *FROM AQ$QT$_XOUT_6 

--查询队列的订阅者,或者说是消费者,对应字段consumer_name
SELECT * FROM dba_queue_subscribers WHERE queue_name = 'Q$_XOUT_5';

--获取当前数据库SCN，注意当前的scn会不断的增长，哪怕你没有进行任何操作，因为数据库的后台会做一些动作（比如checkpoint、LGWR、系统监控进程等）使得scn不断增长
SELECT CURRENT_SCN FROM V$DATABASE;


-- 查询服务名称的出站进程的当前 SCN 位置，以及位置position
SELECT * FROM DBA_XSTREAM_OUTBOUND_PROGRESS WHERE SERVER_NAME = 'XOUT'; -- 替换为您的出站服务器名


-- 检查数据库当前 SCN 范围
SELECT 
  (SELECT oldest_flashback_scn FROM v$flashback_database_log) AS min_scn,
  (SELECT current_scn FROM v$database) AS current_scn
FROM dual;

--查询server name为XOUT的队列状态，必须确保：enqueue_enabled 和 dequeue_enabled 均为 YES
SELECT name, queue_table, enqueue_enabled, dequeue_enabled
FROM dba_queues
WHERE name = (
  SELECT queue_name 
  FROM dba_xstream_outbound 
  WHERE server_name='XOUT'
);

--查询XOUT的捕获进程名
SELECT capture_name FROM dba_xstream_outbound WHERE server_name = 'XOUT';

--查询所有捕获进程的状态，正常值是ENABL
SELECT capture_name, status, error_message FROM dba_capture;

```
## 2. Kafka 配置说明
本配置中，Kafka(kraft)默认是已经安装了，进入Kafka的安装目录之后，会发现有一个配置文件config/kraft/server.properties，需要检查一下如下两个配置：

(1). 检查配置项auto.create.topics.enable的值是否为false,如果是false，需要更改为true，如果没有配置为false，此配置项在不配置的情况下的默认配置值为true：

auto.create.topics.enable=true， 如果为false会导致Source connector无法把数据写入到Kafka 的topic中
```
vi config/kraft/server.properties
```
(2).检查配置项log.dirs=的值，此值是一个文件目录名，log.dirs目录需要足够的磁盘空间来存储Kafka主题数据。所需空间主要取决于：

1）初始快照的数据量；

2）变更数据捕获的保留时长。

3）在Kafka集群多节点的情况下，需要查看上述每个节点的配置，另外还需要结合复制因子来确定存储空间的配置

建议根据业务数据量和保留策略进行预估， 在kev value schema 的模式下(即数据写入topic的时候携带详细的schema信息)，此目录的存储空间必须是源端数据库快照数据的12倍以上，最好是15倍:


## 3. Kafka connect配置说明

进入kafka的安装目录之后，会发现有一个配置文件config/connect-distributed.properties，需要对此配置文件增加如下的配置：

(1). bootstrap.servers=172.16.90.88:9092  #此配置需要配置所有Kafka Broker集群列表，采用“,”逗号隔开

(2).key.converter.schemas.enable=true    #检查一下此配置项的值是否为true，否则source connector写入数据到kafka topic的数据不带schema详细信息，从而导致sink connector无法解析报no schema的错误

(3).value.converter.schemas.enable=true   #检查一下此配置项的值是否为true，否则会source connector写入数据到kafka topic的数据不带schema详细信息，从而导致sink connector无法解析报no schema的错误

(4).plugin.path=/root/install/kafka/kafka_2.12-3.7.2/plugins  #配置kafka的插件存放目录，此配置需要根据kafka实际安装的目录而进行配置
```
vi config/connect-distributed.properties
```
## 4. debezium kafka source connector配置说明

### 4.1 下载相关组件

1).下载debezium-connector-oracle组件包

* 网址：https://repo1.maven.org/maven2/io/debezium/debezium-connector-oracle/3.3.1.Final/debezium-connector-oracle-3.3.1.Final.jar
* 下载文件名：debezium-connector-oracle-3.3.1.Final-plugin.tar.gz
* 说明：需下载支持xstream的版本，比如下载版本3.3.1.Final

2). 下载Oracle 的Jdbc17驱动包

* 网址：https://repo1.maven.org/maven2/com/oracle/database/jdbc/ojdbc17/23.9.0.25.07/ojdbc17-23.9.0.25.07.jar
* 下载文件：ojdbc17-23.9.0.25.07.jar
* 说明：此驱动文件需要与当前安装的java版本相对应

3).下载xstream组件包

* 网址：https://jenkins-tools.yasdb.com/packages/YMP/yas-data-sync/XStream/OCI%28XStream%29/
* 下载文件名：instantclient-basic-linux.x64-21.19.0.0.0dbru.zip
* 说明：上面是我们的一个内网，请选择下载21.19.0.0.0版本，其它版本在当前环境下面运行的时候会报缺少依赖组件的错误

4).特别说明

* 如果你的服务器支持外网，上述文件也可以直接下载到服务器相关的目录，具体目录可以参考下面的安装目录

### 4.2 安装
先检测kafka的安装目录下面是否已经存在了plugins目录(/root/install/kafka/kafka_2.12-3.7.2/plugins)，如果不存在plugins，请创建此目录，之后把上面下载的debezium-connector-oracle-3.3.1.Final-plugin.tar.gz文件上传至plugins，之后解压，如下命令

```
cd kafka_2.12-3.7.2
ls plugins  #检查是否存在plugins，如果不存在就执行下面的命令创建此目录
mkdir plugins  #创建plugins目录
cd plugins  #此时可以上传或者下载debezium-connector-oracle的安装包文件debezium-connector-oracle-3.3.1.Final-plugin.tar.gz至此目录下面
tar zxf debezium-connector-oracle-3.3.1.Final-plugin.tar.gz  #此命令会创建debezium-connector-oracle目录，并且把解压的内容放入此目录里面
cd debezium-connector-oracle
```
上面进入debezium-connector-oracle目录之后，把上面下载的Oracle的jdbc驱动包ojdbc17-23.9.0.25.07.jar放到此目录下面。

再把上面下载的组件包instantclient-basic-linux.x64-21.19.0.0.0dbru.zip放到此目录下面，进行解压，解压之后可以看到生成了一个instantclient_21_19目录，此目录下面有多个以lib开通的库文件

```
unzip instantclient-basic-linux.x64-21.19.0.0.0dbru.zip 
rm -rf instantclient-basic-linux.x64-21.19.0.0.0dbru.zip

#把解压之后的instantclient_21_19/xstreams.jar文件移动到当前目录下面，否则Debezium Oracle Connector无法加载此jar文件
mv instantclient_21_19/xstreams.jar .  
#进入此目录下面，查看是否包含多个以lib开头的库文件
cd instantclient_21_19
```
### 4.3 环境变量配置
xstream的运行需要依赖目录instantclient_2下面的库文件，需要告知操作系统这些文件的路径，为环境变量LD_LIBRARY_PATH添加此目录即可

```
#在~/.bashrc文件的最后把instantclient_2所在的完整路径添加到环境变量LD_LIBRARY_PATH中，比如：export LD_LIBRARY_PATH=/root/install/kafka/kafka_2.12-3.7.2/plugins/debezium-connector-oracle/instantclient_19_19:$LD_LIBRARY_PATH
vi ~/.bashrc

source ~/.bashrc  #使之立马生效
```


# 5. confluent Kafka sink connetor  配置说明

相对于其它开源的sink connetor，confluent更通用，原生支持avro Schema Registry。confluent Kafka sink connetor也是以插件的方式在Kafka平台下面启动，
### 5.1 下载组件
1).下载confluentinc-kafka-connect-jdbc组件包

* 网址：https://www.confluent.io/hub/confluentinc/kafka-connect-jdbc， 进入网页之后，会看到下载按钮，点击之后选择需要下载的版本
* 下载文件名：confluentinc-kafka-connect-jdbc-10.8.4.zip
* 说明：本文档编写时，最新版本已经是10.8.5了。

2).下载YaShanDB Jdbc组件包
* 网址：可以通过YaShan官方发布的网站进行下载
* 下载文件名：yashandb-jdbc-1.9.3.jar
* 说明：YaShanDB 版本是23.4.1.102


### 5.2 安装
先进入Kafka的plugins目录(/root/install/kafka/kafka_2.12-3.7.2/plugins)，之后把上面下载的confluentinc-kafka-connect-jdbc-10.8.4.zip文件上传至此目录下面，之后解压，如下命令

```
cd kafka_2.12-3.7.2/plugins
unzip confluentinc-kafka-connect-jdbc-10.8.4.zip
rm -rf confluentinc-kafka-connect-jdbc-10.8.4.zip
mv confluentinc-kafka-connect-jdbc-10.8.4 jdbc-sink
cd jdbc-sink
rm -rf assets    #删除不必要的文件
rm -rf etc       #删除不必要的文件
rm -rf manifest.json   #删除不必要的文件
rm -rf doc   #删除不必要的文件
```
上述删除不必要的文件之后，剩下lib目录，之后再进入lib目录，并且把上面下载的yashandb-jdbc-1.9.3.jar文件上传至此目录下面
```
cd lib
ls  #确认一下yashandb-jdbc-1.9.3.jar文件是否存在

```


# 6. 重启Kafka和Kafka connector

## 6.1 重启
完成上述配置之后，进入Kafka的安装目录，如果上面更改了kafka的配置，需要重新启动kafka,可以先使用jps命令查看java进程，支持通过kill -9 进程号  命令关闭进程
```
cd kafka_2.12-3.7.2

jps  #查看java进程

#重新启动kafka，上述如果更改了Kafka的配置，那么就需要重新启动，如果没有更改，那么无需进行重新启动
./bin/kafka-server-start.sh -daemon ./config/kraft/server.properties     

#启动kafka connector
nohup ./bin/connect-distributed.sh config/connect-distributed.properties &
```
## 6.2 验证
Kafka 和 Kafka connector启动完成之后，上述配置的插件会加入到Kafka connector中，通过如下命令可以查询是否加载成功
```
curl -s http://172.16.90.88:8083/connector-plugins   #其中172.16.90.88是本服务器ip地址
```
从上述命令输出的内容中查看是否包含如下内容：

"class":"io.confluent.connect.jdbc.JdbcSinkConnector","type":"sink"

"class":"io.debezium.connector.oracle.OracleConnector","type":"source"

如果没有发现上述两个插件，那么上述配置插件的配置失败，需要重新审核一下上述配置。



# 7 启动数据同步任务

## 7.1 source connector任务
### 7.1.1 启动source connector任务
```
curl -i -X POST -H "Accept:application/json" -H "Content-Type:application/json" 172.16.90.88:8083/connectors/ -d '{
  "name": "oracle-source-connector018", 
  "config": {
    "connector.class": "io.debezium.connector.oracle.OracleConnector",
    "topic.prefix": "ora_server018",	
    "schema.history.internal.kafka.topic": "schema-changes.inventory018",
    "database.hostname": "172.16.90.88",
    "database.port": "12901",
    "database.user": "c##xstrmadmin",
    "database.password": "123456",
    "database.dbname" : "ORCLCDB",
    "database.pdb.name" : "ORCLPDB1",
    "database.connection.adapter": "xstream",
    "database.out.server.name": "XOUT",
    "schema.include.list": "HHL001",
    "snapshot.mode": "initial",
    "snapshot.max.threads": "4",
    "lob.enabled": "true",
    "max.queue.size": "16384",
    "max.batch.size": "4096",
    "schema.history.internal.kafka.bootstrap.servers": "172.16.90.88:9092",
    "producer.override.batch.size": "131072",
    "producer.override.linger.ms": "50",
    "producer.override.buffer.memory": "134217728"
  }
}'
```
主要参数说明如下：

| ID | 参数名 | 功能           | 说明                                           |
|----|--------|--------------|----------------------------------------------|
| 1 | `name` | 连接器名称        | Source Connector 的唯一标识符，用于管理和监控              |
| 2 | `connector.class` | 连接器类         | 指定使用的 Debezium Oracle 连接器实现类                 |
| 3 | `topic.prefix` | 主题前缀         | 生成 Kafka 主题名称的前缀，格式为`前缀.模式名.表名`              |
| 4 | `schema.history.internal.kafka.topic` | 模式历史主题       | 存储数据库模式变更历史的 Kafka 主题名称                      |
| 5 | `database.hostname` | 数据库主机地址      | Oracle 数据库服务器的 IP 地址或主机名                     |
| 6 | `database.port` | 数据库端口        | 此端口必须与Oracle数据库服务器的实际监听端口（通常为1521）一致，请根据实际环境修改。 |
| 7 | `database.user` | 数据库用户名       | 连接 Oracle 数据库的用户名，需具有 XStream 权限             |
| 8 | `database.password` | 数据库密码        | 对应用户的数据库连接密码                                 |
| 9 | `database.dbname` | 数据库名称        | CDB（容器数据库）的名称                                |
| 10 | `database.pdb.name` | PDB 名称       | PDB（可插拔数据库）的名称，在 CDB 中唯一标识                   |
| 11 | `database.connection.adapter` | 数据库连接适配器     | 指定变更数据捕获方式，XStream 是 Oracle 官方方案             |
| 12 | `database.out.server.name` | XStream 输出服务器 | 在 Oracle 中配置的 XStream 出站服务器名称                |
| 13 | `schema.include.list` | 模式包含列表       | 指定要捕获变更的 schema，多个用逗号分隔                      |
| 14 | `snapshot.mode` | 快照模式         | 初始快照策略，initial 表示首次启动时执行全量快照                 |
| 15 | `snapshot.max.threads` | 快照最大线程数      | 执行快照时使用的最大并行线程数，影响快照性能                       |
| 16 | `lob.enabled` | LOB 字段支持     | 启用对大对象（CLOB/BLOB）字段变更的捕获支持                   |
| 17 | `max.queue.size` | 最大队列大小       | 连接器内部队列能容纳的最大事件数，影响内存使用                      |
| 18 | `max.batch.size` | 最大批次大小       | 每次从数据库读取的最大事件记录数                             |
| 19 | `schema.history.internal.kafka.bootstrap.servers` | Schema 历史 Kafka 地址 | 存储模式历史的 Kafka 集群的引导服务器地址                     |
| 20 | `producer.override.batch.size` | 生产者批次大小      | 覆盖 Kafka 生产者的 batch.size 配置，提高吞吐量            |
| 21 | `producer.override.linger.ms` | 生产者延迟时间      | 覆盖 Kafka 生产者的 linger.ms，控制批次发送延迟             |
| 22 | `producer.override.buffer.memory` | 生产者缓冲内存      | 覆盖 Kafka 生产者的 buffer.memory，分配更多缓冲空间         |


### 7.1.2 source connector任务检查
启动任务之后，我们需要知道任务是否正常运行，可以结合下面两种方式对任务进行检查

(1). 查看任务运行日志信息：tail -f log/connect.log

(2).查看任务状态
* 浏览器模式：http://172.16.90.88:8083/connectors/oracle-source-connector018/status
* 命令模式：curl -s -X GET http://172.16.90.88:8083/connectors/oracle-source-connector018/status

### 7.1.3 调试source connector任务
在调试source connector任务时，通常一套参数需要反复进行调测，并且希望此任务都能正常启动，那么上述source任务修改如下三个参数的值，任务又可以正常运行：
* "name": "oracle-source-connector018",  比如可以把此参数值中的018，修改为019
* "topic.prefix": "ora_server018",    比如可以把此参数值中的018，修改为019
* "schema.history.internal.kafka.topic": "schema-changes.inventory018"    ,比如可以把此参数值中的018，修改为019

通过修改名称和关联的主题前缀，可以避免与已有任务冲突，实现同一套配置的并行测试
## 7.2 sink connector任务
### 7.2.1 启动Sink connector任务

```
curl -i -X POST -H "Accept:application/json" -H "Content-Type:application/json" 172.16.90.88:8083/connectors/ -d '{
  "name": "yashandb-sink-connector018",
  "config": {
    "connector.class": "io.confluent.connect.jdbc.JdbcSinkConnector",
    "tasks.max": "1",
    "topics.regex": "ora_server018\\.HHL001\\..*",
    "key.converter": "org.apache.kafka.connect.json.JsonConverter",
    "key.converter.schemas.enable": "true",
    "value.converter": "org.apache.kafka.connect.json.JsonConverter",
    "value.converter.schemas.enable": "true",
    "connection.driver.class": "com.yashandb.jdbc.Driver",
    "connection.url": "jdbc:yasdb://172.16.90.87:1688/YaShanDB",
    "connection.user": "HHL001",
    "connection.password": "123456",
    "table.name.format": "${topic}",
    "table.name.normalize": "true",
    "pk.mode": "record_key", 
    "insert.mode": "upsert",
    "auto.create": "true",
    "auto.evolve": "true",
    "transforms": "unwrap,removeMeta,route",
    "transforms.unwrap.type": "io.debezium.transforms.ExtractNewRecordState",
    "transforms.unwrap.drop.tombstones": "true",
    "transforms.unwrap.delete.handling.mode": "rewrite",
    "transforms.route.type": "org.apache.kafka.connect.transforms.RegexRouter",
    "transforms.route.regex": "ora_server018\\.HHL001\\.(.+)",
    "transforms.route.replacement": "$1",
    "transforms.removeMeta.type": "org.apache.kafka.connect.transforms.ReplaceField$Value",
    "transforms.removeMeta.blacklist": "__deleted,__source,__op,__ts_ms",
    "batch.size": "1000",
    "max.retries": "10",
    "retry.backoff.ms": "3000",
    "numeric.mapping": "best_fit",
    "dialect.name": "OracleDatabaseDialect",
    "quote.sql.identifiers": "always"
  }
}'
```

主要参数说明如下：

| ID | 参数名 | 功能 | 说明                                       |
|----|--------|------|------------------------------------------|
| 1 | `name` | 连接器名称 | Sink Connector 的唯一标识符，用于管理和监控            |
| 2 | `connector.class` | 连接器类 | 指定使用的 JDBC Sink 连接器实现类                   |
| 3 | `tasks.max` | 最大任务数 | 连接器可以创建的最大并行任务数                          |
| 4 | `topics.regex` | 主题正则表达式 | 使用正则表达式匹配要消费的 Kafka 主题                   |
| 5 | `key.converter` | 键转换器 | 键的反序列化器类                                 |
| 6 | `key.converter.schemas.enable` | 键模式启用 | 是否在键中包含模式信息                              |
| 7 | `value.converter` | 值转换器 | 值的反序列化器类                                 |
| 8 | `value.converter.schemas.enable` | 值模式启用 | 是否在值中包含模式信息                              |
| 9 | `connection.driver.class` | 数据库驱动类 | 目标数据库的 JDBC 驱动类名                         |
| 10 | `connection.url` | 数据库连接 URL | 目标数据库的 JDBC 连接字符串                        |
| 11 | `connection.user` | 数据库用户名 | 连接目标数据库的用户名                              |
| 12 | `connection.password` | 数据库密码 | 连接目标数据库的密码                               |
| 13 | `table.name.format` | 表名格式 | 目标表名的格式化模板，支持变量替换                        |
| 14 | `table.name.normalize` | 表名规范化 | 是否自动规范化表名（如大小写转换）                        |
| 15 | `pk.mode` | 主键模式 | 如何确定数据库表的主键                              |
| 16 | `insert.mode` | 插入模式 | 数据插入数据库的方式。upsert值表示记录存在则更新(依靠主键)，不存在则插入 |
| 17 | `auto.create` | 自动创建表 | 是否自动创建不存在的表                              |
| 18 | `auto.evolve` | 自动演进表结构 | 是否自动添加新列到现有表                             |
| 19 | `transforms` | 数据转换链 | 应用于消息的数据转换处理器列表                          |
| 20 | `transforms.unwrap.type` | 解包转换类型 | 提取新记录状态的转换器                              |
| 21 | `transforms.unwrap.drop.tombstones` | 删除墓碑记录 | 是否删除代表删除的墓碑记录                            |
| 22 | `transforms.unwrap.delete.handling.mode` | 删除处理模式 | 处理删除记录的方式                                |
| 23 | `transforms.route.type` | 路由转换类型 | 基于正则表达式的主题路由转换器                          |
| 24 | `transforms.route.regex` | 路由正则表达式 | 用于匹配和提取主题名的正则表达式                         |
| 25 | `transforms.route.replacement` | 路由替换模式 | 生成新主题名的替换模式                              |
| 26 | `transforms.removeMeta.type` | 元数据移除类型 | 移除指定字段的转换器                               |
| 27 | `transforms.removeMeta.blacklist` | 元数据黑名单 | 要从值中移除的字段列表                              |
| 28 | `batch.size` | 批次大小 | 每次写入数据库的记录数                              |
| 29 | `max.retries` | 最大重试次数 | 操作失败时的最大重试次数                             |
| 30 | `retry.backoff.ms` | 重试退避时间 | 重试之间的等待时间（毫秒）                            |
| 31 | `numeric.mapping` | 数值映射策略 | 数值类型的映射策略                                |
| 32 | `dialect.name` | 数据库方言 | 目标数据库的方言类名                               |
| 33 | `quote.sql.identifiers` | SQL标识符引号 | 是否始终用引号引用SQL标识符                          |


### 7.2.3 调试sink connector任务
在调试sin connector任务时，通常一套参数需要反复进行调测，并且希望此任务都能正常启动，那么上述sink任务修改如下三个参数的值任务就可以正常运行：
* "name": "yashandb-sink-connector018",  比如可以把此参数值中的018，修改为019

## 7.3 其它相关任务操作命令

(1).查看服务器下的所有任务

curl -s -X GET http://172.16.90.88:8083/connectors

(2).查询服务器172.16.90.88:8083下名称为yashandb-connector002的任务状态

curl -s -X GET http://10.9.6.82:8083/connectors/yashandb-connector002/status

(3).查询服务器172.16.90.88:8083下名称为yashandb-connector002的任务的配置

curl -s -X GET http://172.16.90.88:8083/connectors/oracle-source-connector038/config

(4).删除服务器172.16.90.88:8083下名称是oracle-source-connector002的任务

curl -X DELETE http://172.16.90.88:8083/connectors/oracle-source-connector002

(5).重新启动服务器172.16.90.88:8083下名称是oracle-source-connector002的任务

curl -X PUT http://172.16.90.88:8083/connectors/oracle-source-connector002/resume

(6).通过任务配置文件启动任务， -d @filename 指定当前目录下面任务配置文件(json格式的文件)

curl -X PUT http://172.16.90.88:8083/connectors/oracle-source-connector002/config -H "Content-Type: application/json" -d @updated-config.json


# 8 免责声明
## 8.1 法律声明
本文档仅作为技术参考和指导，不提供任何形式的担保。使用本文档提供的信息，您应自行承担风险。作者和文档贡献者不对因使用本文档信息而导致的任何损失或损害承担责任。

## 8.2 第三方软件许可与版权声明
(1). Oracle 功能许可确认

重要提醒：本文档中描述和使用的 Oracle XStream技术是 Oracle 数据库企业版的一项高级功能。使用此功能可能需要购买相应的 Oracle 数据库企业版许可及相关的“Oracle GoldenGate”或“Oracle Advanced Replication”选项许可。用户有责任自行核实其持有的 Oracle 许可协议是否涵盖了 XStream 功能的使用。文档作者不对用户的软件许可合规性承担任何责任

(2). 建议与核实

在根据本文档进行生产环境部署之前，强烈建议您：

* 联系您的 Oracle 销售代表或查阅您的 Oracle 许可协议，确认 XStream 功能的授权状态。

* 评估并使用可能无需额外许可的替代方案（例如，对于 Oracle 源端，可评估是否适用 LogMiner，但其功能有限制）

(3).开源与商业软件区分

本文档同时涉及开源软件（如 Apache Kafka, Debezium、Confluent ）和商业软件（如 Oracle Database）。用户需自行了解并遵守不同软件的不同授权要求。

## 8.3 使用前提
(1).技术能力要求：使用者应具备基本的数据库管理、Kafka运维和系统管理知识

(2).环境差异：本文档基于特定环境编写，实际部署时需根据具体环境进行调整

(3).版本兼容性：不同软件版本可能存在差异，请确保组件版本兼容性


## 8.4 风险提示
### 8.4.1 数据安全风险
* 在生产环境实施前，务必在测试环境进行充分验证
* 建议先对重要数据进行完整备份
* 数据迁移过程中可能存在数据丢失或损坏的风险

### 8.4.2 系统稳定性风险
* 配置变更可能影响系统稳定性
* 不正确的配置可能导致服务中断
* 建议在业务低峰期进行操作

### 8.4.3 性能影响
* 数据同步可能对源数据库性能产生影响
* 请评估对生产系统的影响后再实施